# DEPRECATED — legacy SLM experiments

Retired on 2026-09-16 by user request. All reports, scores, plans and model artifacts in this archive are historical reference only. They are not the current baseline or evidence for the fresh 47-source training. Original payloads are preserved byte-for-byte; this notice supersedes historical current-status language. Restore only into an explicit temporary reference directory, then remove the unpacked copy after use. Do not resume old controllers.
