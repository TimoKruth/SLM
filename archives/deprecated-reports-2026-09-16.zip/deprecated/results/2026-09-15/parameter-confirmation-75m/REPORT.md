# Matched 75M parameter confirmation results

Fixed 75M comparison on previously unconsumed suite groups: 256 original-validation tasks and 1104 internal-dev tasks. Internal dev may have been exposed via development loss. Fixed parent and two data orders, not independent initializations or external transfer. Intervals remain exploratory; surface flags overlap.

| Checkpoint | Additional tokens | Accuracy (family macro) | Correct / scored | Answer loss |
|---|---:|---:|---:|---:|
| parent | parent | 26.55% | 337 / 1280 | 1.4470 |
| r0-A-75M | 75001030 | 27.20% | 345 / 1280 | 1.4463 |
| r0-D-75M | 75001030 | 28.53% | 354 / 1280 | 1.4194 |
| r1-A-75M | 75000676 | 27.46% | 346 / 1280 | 1.4435 |
| r1-D-75M | 75000676 | 26.18% | 336 / 1280 | 1.4157 |

| Paired comparison | Order 0 (pp) | Order 1 (pp) | Mean (pp) | Exploratory 95% interval (pp) |
|---|---:|---:|---:|---:|
| D-A-75M | +1.33 | -1.28 | +0.03 | -1.51 to +1.46 |
| A-parent-75M | +0.65 | +0.92 | +0.78 | -1.18 to +2.83 |
| D-parent-75M | +1.98 | -0.36 | +0.81 | -1.05 to +2.76 |

All five evaluations and 6,800 saved generations validated with the frozen scorer. The 75M snapshots match tokens and updates exactly within each data order. No training or checkpoint selection after viewing these scores.

Intervals use 5,000 paired group resamples within source, keeping both data orders paired and preserving source/family macro weights. Parent comparisons reuse the same parent responses across orders. The predeclared decision gates below are applied without automatic model adoption.

Per-source/family diagnostics, gains/losses, and source-composition sensitivity intervals are in analysis.json. All 25 source quotas are complete; five sources remain outside correctness scoring.

## Predeclared decision gates

- gain_vs_A_in_both_orders: False
- beats_parent_in_both_orders: False
- family_regressions_within_limit: True
- all_quality_gates_passed: False
- decision: No supported replacement; retain parent as reference
