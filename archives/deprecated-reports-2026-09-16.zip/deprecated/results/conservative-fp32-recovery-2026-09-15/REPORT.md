# Optimization screening

| Candidate | Median speedup | Decision |
|---|---:|---|
| aa | 1.003× | no_consistent_screening_gain |
| deferred4 | 1.029× | no_consistent_screening_gain |

Descriptive paired screening, not statistical significance or long-run quality proof.

All candidates still require independent confirmation, checkpoint-resume validation and a full-pipeline comparison before adoption.
